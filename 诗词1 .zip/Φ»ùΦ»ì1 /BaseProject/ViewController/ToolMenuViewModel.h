//
//  ToolMenuViewModel.h
//  BaseProject
//
//  Created by ios－23 on 15/11/11.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "BaseViewModel.h"

@interface ToolMenuViewModel : BaseViewModel

@end
