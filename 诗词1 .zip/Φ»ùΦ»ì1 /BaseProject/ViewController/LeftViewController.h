//
//  LeftViewController.h
//  BaseProject
//
//  Created by ios－23 on 15/11/9.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LeftViewController : UIViewController

@end
