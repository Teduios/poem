//
//  FirstViewController.h
//  BaseProject
//
//  Created by ios－23 on 15/11/6.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FirstViewController : UIViewController


@property (weak, nonatomic) IBOutlet UILabel *titleLable;
@end
