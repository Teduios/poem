//
//  PoetryDetailViewController.h
//  BaseProject
//
//  Created by jiyingxin on 15/10/29.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import <UIKit/UIKit.h>







@interface PoetryDetailViewController : UIViewController



-(id)initWithShi:(NSString *)shi intro:(NSString *)shiIntro;
@property(nonatomic,strong) NSString *shi;
@property(nonatomic,strong) NSString *shiIntro;
@property(nonatomic,strong) NSString *shiTitle;
//@property (nonatomic,assign )BOOL rember;

@end













