//
//  RemberDetailViewController.h
//  BaseProject
//
//  Created by ios－23 on 15/11/12.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RemberDetailViewController : UIViewController
-(id)initWithTitle:(NSString *)title;
@property (nonatomic,strong)NSString *shititle;
@end
