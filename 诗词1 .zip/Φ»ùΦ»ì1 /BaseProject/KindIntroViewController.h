//
//  KindIntroViewController.h
//  BaseProject
//
//  Created by jiyingxin on 15/10/28.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface KindIntroViewController : UIViewController
@property(nonatomic,strong) NSString *introKind;
@end












